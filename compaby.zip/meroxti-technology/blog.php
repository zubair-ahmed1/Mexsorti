<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle = 'Insights & Tech Articles \vert{} MEROXTI TECHNOLOGY';$pageDescription = 'Ideas, expert perspectives, and practical insights on web development, custom software, AI, and digital growth.';
$canonicalUrl = '';$activePage = 'blog';

// Site base path
$siteBase = '/MEROXTI%20TECHNOLOGY/meroxti-technology-starter/meroxti-technology';

// Safe Database Connection Include (matching your schema `meroxti_technology`)
if (file_exists(__DIR__ . '/config/database.php')) {
    require_once __DIR__ . '/config/database.php';
} elseif (file_exists(__DIR__ . '/config/dataphase.php')) {
    require_once __DIR__ . '/config/dataphase.php';
} elseif (file_exists(__DIR__ . '/includes/db.php')) {
    require_once __DIR__ . '/includes/db.php';
} else {
    $dbHost = '127.0.0.1';
    $dbName = 'meroxti_technology';
    $dbUser = 'root';$dbPass = '';
    try {
        $pdo = new PDO("mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4", $dbUser,$dbPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } catch (Exception $e) {$pdo = null;
    }
}

// Fetch Blog Posts from Database (`posts` or `blogs` table) if available
$postsList = [];
try {
    if (isset($pdo) &&$pdo) {
        $stmt =$pdo->query("SELECT * FROM posts WHERE status = 'published' ORDER BY id DESC");
        $postsList =$stmt->fetchAll();
    }
} catch (Exception $e) {$postsList = [];
}

// Fallback Professional Articles Suite if database is empty or tables not yet seeded
if (empty($postsList)) {$postsList = [
        [
            'title' => 'The Future of Enterprise SaaS Architecture',
            'category' => 'Cloud & Software',
            'published_at' => 'October 12, 2026',
            'summary' => 'Explore how multi-tenant microservices and automated database indexing are transforming high-scale enterprise applications.',
            'slug' => 'future-enterprise-saas-architecture'
        ],
        [
            'title' => 'Integrating Practical AI Pipelines into Workflows',
            'category' => 'Artificial Intelligence',
            'published_at' => 'October 05, 2026',
            'summary' => 'A comprehensive guide on leveraging autonomous machine learning models to reduce operational friction and boost team velocity.',
            'slug' => 'practical-ai-pipelines-corporate-workflows'
        ],
        [
            'title' => 'Optimizing Full-Stack Performance for Global Scale',
            'category' => 'Web Engineering',
            'published_at' => 'September 28, 2026',
            'summary' => 'Best practices in PHP PDO caching, asynchronous asset loading, and responsive design systems for modern digital platforms.',
            'slug' => 'optimizing-fullstack-performance-global-scale'
        ]
    ];
}

function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

// Include Header & Navbar
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/navbar.php';
?>

<main id="main-content">
    <!-- BLOG HERO SECTION -->
    <section class="blog-hero-section section-shell section-pad">
        <div class="blog-hero-copy reveal">
            <div class="eyebrow">
                <span class="status-dot"></span>
                EXPERT PERSPECTIVES & IDEAS
            </div>
            <h1>
                Ideas for
                <span class="gradient-text">what's next.</span>
            </h1>
            <p class="hero-lead">
                Explore expert articles, technical breakthroughs, and practical insights on web development, 
                artificial intelligence, and scalable software engineering.
            </p>
            <div class="hero-actions">
                <a class="btn btn-primary-custom" href="<?= e($siteBase) ?>/contact.php">
                    Start a conversation <span aria-hidden="true">↗</span>
                </a>
                <a class="text-link" href="#blog-matrix">
                    Read articles <span aria-hidden="true">↓</span>
                </a>
            </div>
        </div>

        <!-- Center-Aligned VIP Insights Metrics -->
        <div class="blog-hero-visual reveal" aria-hidden="true">
            <div class="visual-glow"></div>
            <div class="vip-about-stat-card">
                <div class="stat-icon-badge">💡</div>
                <div class="stat-content">
                    <strong>Expert</strong>
                    <span>Technical Insights</span>
                </div>
            </div>
            <div class="vip-about-stat-card card-offset">
                <div class="stat-icon-badge">📈</div>
                <div class="stat-content">
                    <strong>Scale</strong>
                    <span>Strategies & Trends</span>
                </div>
            </div>
        </div>
    </section>

    <!-- BLOG MATRIX GRID SECTION -->
    <section class="section-shell section-pad" id="blog-matrix">
        <div class="section-heading reveal">
            <div>
                <div class="eyebrow">LATEST PUBLICATIONS</div>
                <h2>
                    Knowledge sharing &
                    <span class="gradient-text">industry standards.</span>
                </h2>
            </div>
            <p>
                Backed by active MySQL database indexing and engineering research.
            </p>
        </div>

        <div class="vip-blog-grid">
            <?php foreach ($postsList as $index =>$post): ?>
                <article class="vip-blog-card reveal" style="--card-delay: <?= (int)$index * 90 ?>ms">
                    <div class="card-top-row">
                        <span class="card-index"><?= str_pad((string)($index + 1), 2, '0', STR_PAD_LEFT) ?></span>
                        <span class="card-status-badge"><?= e($post['category'] ?? 'Tech Insight') ?></span>
                    </div>
                    <h3><?= e($post['title']) ?></h3>
                    <?php if (!empty($post['published_at'])): ?>
                        <span class="blog-date-label">Published: <strong><?= e($post['published_at']) ?></strong></span>
                    <?php endif; ?>
                    <p><?= e($post['summary'] ?? $post['short_description'] ?? 'In-depth analysis of modern engineering methodologies and digital transformation trends.') ?></p>
                    
                    <div class="card-bottom-row">
                        <span class="tech-stack-tag">Database Synchronized</span>
                        <a class="card-link" href="<?= e($siteBase) ?>/contact.php">
                            Read article <span>↗</span>
                        </a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- CALL TO ACTION BANNER -->
    <section class="section-shell section-pad project-preview">
        <div class="project-panel reveal">
            <div class="project-panel-copy">
                <div class="eyebrow">READY TO INNOVATE?</div>
                <h2>
                    Have a project in mind? Let's build
                    <span class="gradient-text">something exceptional.</span>
                </h2>
                <p>
                    Connect with our development leads and discover how our technical expertise can scale your business.
                </p>
                <a class="btn btn-primary-custom" href="<?= e($siteBase) ?>/contact.php">
                    Start a conversation <span>↗</span>
                </a>
            </div>

            <div class="project-orb" aria-hidden="true">
                <div class="orb-inner">MX</div>
                <span class="orb-label label-one">IDEAS</span>
                <span class="orb-label label-two">STRATEGY</span>
                <span class="orb-label label-three">GROWTH</span>
            </div>
        </div>
    </section>
</main>

<?php require __DIR__ . '/includes/footer.php'; ?>

<!-- Scroll Animation Script -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    const animatedItems = document.querySelectorAll('.reveal');

    if (!('IntersectionObserver' in window)) {
        animatedItems.forEach(function (item) {
            item.classList.add('active');
        });
        return;
    }

    const observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1
    });

    animatedItems.forEach(function (item) {
        observer.observe(item);
    });
});
</script>   