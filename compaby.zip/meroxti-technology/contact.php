<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$pageTitle = 'Contact Executive Team | MEROXTI TECHNOLOGY';
$pageDescription = 'Tell us about your next website, custom software, AI integration, or mobile application project. Let us build something meaningful together.';
$canonicalUrl = '';
$activePage = 'contact';

// Dynamic Site Base Path Resolution
$scriptDir = dirname($_SERVER['SCRIPT_NAME']);
$siteBase = ($scriptDir === '/' || $scriptDir === '\\') ? '' : rtrim(str_replace('\\', '/', $scriptDir), '/');

// Safe Database Connection Include
if (file_exists(__DIR__ . '/config/database.php')) {
    require_once __DIR__ . '/config/database.php';
} elseif (file_exists(__DIR__ . '/config/dataphase.php')) {
    require_once __DIR__ . '/config/dataphase.php';
} elseif (file_exists(__DIR__ . '/includes/db.php')) {
    require_once __DIR__ . '/includes/db.php';
} else {
    $dbHost = '127.0.0.1';
    $dbName = 'meroxti_technology';
    $dbUser = 'root';
    $dbPass = '';
    try {
        $pdo = new PDO("mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4", $dbUser, $dbPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } catch (Exception $e) {
        $pdo = null;
    }
}

function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

// Include Header & Navbar
require_once __DIR__ . '/includes/header.php';
require_once __DIR__ . '/includes/navbar.php';
?>

<main id="main-content">
    <!-- CONTACT HERO & FORM SECTION -->
    <section class="contact-hero-section section-shell section-pad">
        <div class="contact-header-wrap reveal">
            <div class="eyebrow">
                <span class="status-dot"></span>
                CONNECT WITH OUR ENGINEERS
            </div>
            <h1>
                Let's build something
                <span class="gradient-text">meaningful.</span>
            </h1>
            <p class="hero-lead">
                Tell us about your upcoming web platform, custom SaaS software, AI pipeline, or mobile application. 
                Our technical leads will review your requirements and get back to you promptly.
            </p>
        </div>

        <?php if (isset($_GET['sent'])): ?>
            <div class="vip-notice-success reveal" role="status" style="margin-bottom: 30px; padding: 20px; border: 1px solid rgba(16, 185, 129, 0.4); border-radius: 16px; background: rgba(16, 185, 129, 0.1); display: flex; align-items: center; gap: 16px;">
                <span class="notice-icon" style="display: grid; width: 36px; height: 36px; place-items: center; border-radius: 50%; background: #10b981; color: #fff; font-weight: 700;">✓</span>
                <div>
                    <strong style="color: #fff; font-size: 1.05rem;">Message Received Successfully</strong>
                    <p style="margin: 0; color: var(--muted); font-size: 0.95rem;">Thank you for reaching out. Our executive team has received your inquiry and will contact you shortly.</p>
                </div>
            </div>
        <?php endif; ?>

        <div class="contact-card-container reveal" style="--card-delay: 100ms;">
            <div class="card-glow-border"></div>
            <form class="vip-contact-form" action="actions/submit-contact.php" method="post">
                <input type="hidden" name="csrf_token" value="<?= e($_SESSION['csrf_token']) ?>">
                
                <div class="form-grid" style="display: grid; grid-template-columns: repeat(2, minmax(0, 1fr)); gap: 20px;">
                    <div class="form-group" style="display: flex; flex-direction: column; gap: 8px;">
                        <label for="name" style="color: #cbd5e1; font-weight: 600; font-size: 0.9rem;">Your Full Name *</label>
                        <input type="text" id="name" name="name" autocomplete="name" required maxlength="120" placeholder="e.g. Alex Morgan" style="padding: 14px 18px; border: 1px solid var(--border); border-radius: 12px; background: rgba(15, 23, 42, 0.6); color: #fff; outline: none;">
                    </div>

                    <div class="form-group" style="display: flex; flex-direction: column; gap: 8px;">
                        <label for="email" style="color: #cbd5e1; font-weight: 600; font-size: 0.9rem;">Business Email Address *</label>
                        <input type="email" id="email" name="email" autocomplete="email" required maxlength="190" placeholder="alex@company.com" style="padding: 14px 18px; border: 1px solid var(--border); border-radius: 12px; background: rgba(15, 23, 42, 0.6); color: #fff; outline: none;">
                    </div>

                    <div class="form-group" style="display: flex; flex-direction: column; gap: 8px;">
                        <label for="phone" style="color: #cbd5e1; font-weight: 600; font-size: 0.9rem;">Phone Number (Optional)</label>
                        <input type="tel" id="phone" name="phone" autocomplete="tel" maxlength="40" placeholder="+1 (555) 000-0000" style="padding: 14px 18px; border: 1px solid var(--border); border-radius: 12px; background: rgba(15, 23, 42, 0.6); color: #fff; outline: none;">
                    </div>

                    <div class="form-group" style="display: flex; flex-direction: column; gap: 8px;">
                        <label for="service" style="color: #cbd5e1; font-weight: 600; font-size: 0.9rem;">Service of Interest</label>
                        <select id="service" name="service" style="padding: 14px 18px; border: 1px solid var(--border); border-radius: 12px; background: rgba(15, 23, 42, 0.8); color: #fff; outline: none;">
                            <option value="">Select a core capability</option>
                            <option value="Web Development">Web Ecosystem Engineering</option>
                            <option value="Software Development">Custom SaaS & Software</option>
                            <option value="AI Solutions">Autonomous AI Solutions</option>
                            <option value="Mobile App Development">Mobile App Development</option>
                            <option value="Cloud DevOps">Cloud Infrastructure & DevOps</option>
                        </select>
                    </div>

                    <div class="form-group full-field" style="grid-column: span 2; display: flex; flex-direction: column; gap: 8px;">
                        <label for="message" style="color: #cbd5e1; font-weight: 600; font-size: 0.9rem;">Project Requirements & Scope *</label>
                        <textarea id="message" name="message" rows="6" required maxlength="10000" placeholder="Describe your technical goals, target timeline, and specific features you want to build..." style="padding: 14px 18px; border: 1px solid var(--border); border-radius: 12px; background: rgba(15, 23, 42, 0.6); color: #fff; outline: none; resize: vertical;"></textarea>
                    </div>
                </div>

                <div class="form-action-row" style="display: flex; align-items: center; justify-content: space-between; margin-top: 30px; flex-wrap: wrap; gap: 20px;">
                    <span class="secure-badge" style="color: var(--muted); font-size: 0.85rem; font-weight: 600;">🔒 256-Bit Encrypted Data Transmission</span>
                    <button class="btn btn-primary-custom" type="submit">
                        Send message <span aria-hidden="true">↗</span>
                    </button>
                </div>
            </form>
        </div>
    </section>
</main>

<?php 
if (file_exists(__DIR__ . '/includes/footer.php')) {
    require_once __DIR__ . '/includes/footer.php'; 
}
?>

<!-- Scroll Animation Script -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    const animatedItems = document.querySelectorAll('.reveal');

    if (!('IntersectionObserver' in window)) {
        animatedItems.forEach(function (item) {
            item.classList.add('active');
        });
        return;
    }

    const observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1
    });

    animatedItems.forEach(function (item) {
        observer.observe(item);
    });
});
</script>