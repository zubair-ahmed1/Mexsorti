<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle = 'Enterprise Projects & Portfolio \vert{} MEROXTI TECHNOLOGY';$pageDescription = 'Explore selected digital work, custom SaaS platforms, and advanced software case studies engineered by MEROXTI TECHNOLOGY.';
$canonicalUrl = '';$activePage = 'projects';

// Site base path
$siteBase = '/MEROXTI%20TECHNOLOGY/meroxti-technology-starter/meroxti-technology';

// Safe Database Connection Include (matching your schema `meroxti_technology`)
if (file_exists(__DIR__ . '/config/database.php')) {
    require_once __DIR__ . '/config/database.php';
} elseif (file_exists(__DIR__ . '/config/dataphase.php')) {
    require_once __DIR__ . '/config/dataphase.php';
} elseif (file_exists(__DIR__ . '/includes/db.php')) {
    require_once __DIR__ . '/includes/db.php';
} else {
    $dbHost = '127.0.0.1';
    $dbName = 'meroxti_technology';
    $dbUser = 'root';$dbPass = '';
    try {
        $pdo = new PDO("mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4", $dbUser,$dbPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } catch (Exception $e) {$pdo = null;
    }
}

// Fetch Projects from Database (`projects` table) if available
$projectsList = [];
try {
    if (isset($pdo) &&$pdo) {
        $stmt =$pdo->query("SELECT * FROM projects WHERE status = 'published' ORDER BY id DESC");
        $projectsList =$stmt->fetchAll();
    }
} catch (Exception $e) {$projectsList = [];
}

// Fallback Professional Projects Suite if database is empty or tables not yet seeded
if (empty($projectsList)) {$projectsList = [
        [
            'title' => 'NexusCloud Enterprise SaaS',
            'client' => 'FinTech Global Corp',
            'category' => 'Cloud Architecture & Web',
            'short_description' => 'A multi-tenant SaaS dashboard managing secure global financial transactions with real-time analytics sync.',
            'slug' => 'nexuscloud-saas'
        ],
        [
            'title' => 'Aura AI Customer Intelligence',
            'client' => 'OmniRetail Systems',
            'category' => 'Artificial Intelligence',
            'short_description' => 'Autonomous machine learning pipeline integrated into customer support workflows to boost resolution speed by 350%.',
            'slug' => 'aura-ai-intelligence'
        ],
        [
            'title' => 'Vanguard Mobile Banking App',
            'client' => 'Apex Trust Bank',
            'category' => 'Mobile Engineering',
            'short_description' => 'High-security cross-platform mobile application supporting biometric authentication and instant peer-to-peer transfers.',
            'slug' => 'vanguard-mobile-app'
        ],
        [
            'title' => 'OmniLogistics Supply Suite',
            'client' => 'TransGlobal Freight',
            'category' => 'Custom Software',
            'short_description' => 'End-to-end automated logistics tracking software optimizing fleet routes, fuel efficiency, and warehouse inventory.',
            'slug' => 'omnilogistics-suite'
        ]
    ];
}

function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

// Include Header & Navbar
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/navbar.php';
?>

<main id="main-content">
    <!-- PROJECTS HERO SECTION -->
    <section class="projects-hero-section section-shell section-pad">
        <div class="projects-hero-copy reveal">
            <div class="eyebrow">
                <span class="status-dot"></span>
                PROVEN DIGITAL EXCELLENCE
            </div>
            <h1>
                Work that moves
                <span class="gradient-text">ideas forward.</span>
            </h1>
            <p class="hero-lead">
                Explore selected enterprise case studies, digital platforms, and high-performance software 
                engineered to accelerate our partners' market leadership.
            </p>
            <div class="hero-actions">
                <a class="btn btn-primary-custom" href="<?= e($siteBase) ?>/contact.php">
                    Start a conversation <span aria-hidden="true">↗</span>
                </a>
                <a class="text-link" href="#projects-matrix">
                    View portfolio <span aria-hidden="true">↓</span>
                </a>
            </div>
        </div>

        <!-- Center-Aligned VIP Portfolio Metrics -->
        <div class="projects-hero-visual reveal" aria-hidden="true">
            <div class="visual-glow"></div>
            <div class="vip-about-stat-card">
                <div class="stat-icon-badge">🏆</div>
                <div class="stat-content">
                    <strong>100%</strong>
                    <span>Successfully Delivered</span>
                </div>
            </div>
            <div class="vip-about-stat-card card-offset">
                <div class="stat-icon-badge">⚡</div>
                <div class="stat-content">
                    <strong>Enterprise</strong>
                    <span>Scalable Infrastructure</span>
                </div>
            </div>
        </div>
    </section>

    <!-- PROJECTS MATRIX GRID SECTION -->
    <section class="section-shell section-pad" id="projects-matrix">
        <div class="section-heading reveal">
            <div>
                <div class="eyebrow">PORTFOLIO MATRIX</div>
                <h2>
                    Featured case studies &
                    <span class="gradient-text">digital deployments.</span>
                </h2>
            </div>
            <p>
                Backed by active MySQL database records and robust enterprise technology standards.
            </p>
        </div>

        <div class="vip-projects-grid">
            <?php foreach ($projectsList as $index =>$project): ?>
                <article class="vip-project-card reveal" style="--card-delay: <?= (int)$index * 90 ?>ms">
                    <div class="card-top-row">
                        <span class="card-index"><?= str_pad((string)($index + 1), 2, '0', STR_PAD_LEFT) ?></span>
                        <span class="card-status-badge"><?= e($project['category'] ?? 'Enterprise Solution') ?></span>
                    </div>
                    <h3><?= e($project['title']) ?></h3>
                    <?php if (!empty($project['client'])): ?>
                        <span class="project-client-label">Client: <strong><?= e($project['client']) ?></strong></span>
                    <?php endif; ?>
                    <p><?= e($project['short_description'] ?? 'High-impact digital product engineered for high availability and performance.') ?></p>
                    
                    <div class="card-bottom-row">
                        <span class="tech-stack-tag">Database Synchronized</span>
                        <a class="card-link" href="<?= e($siteBase) ?>/contact.php">
                            Explore case study <span>↗</span>
                        </a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- CALL TO ACTION BANNER -->
    <section class="section-shell section-pad project-preview">
        <div class="project-panel reveal">
            <div class="project-panel-copy">
                <div class="eyebrow">READY TO BUILD YOUR PROJECT?</div>
                <h2>
                    Let's create something extraordinary
                    <span class="gradient-text">together.</span>
                </h2>
                <p>
                    Share your requirements with our architects and let us turn your vision into a scalable enterprise product.
                </p>
                <a class="btn btn-primary-custom" href="<?= e($siteBase) ?>/contact.php">
                    Discuss your project <span>↗</span>
                </a>
            </div>

            <div class="project-orb" aria-hidden="true">
                <div class="orb-inner">MX</div>
                <span class="orb-label label-one">DESIGN</span>
                <span class="orb-label label-two">CODE</span>
                <span class="orb-label label-three">SCALE</span>
            </div>
        </div>
    </section>
</main>

<?php require __DIR__ . '/includes/footer.php'; ?>

<!-- Scroll Animation Script -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    const animatedItems = document.querySelectorAll('.reveal');

    if (!('IntersectionObserver' in window)) {
        animatedItems.forEach(function (item) {
            item.classList.add('active');
        });
        return;
    }

    const observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1
    });

    animatedItems.forEach(function (item) {
        observer.observe(item);
    });
});
</script>