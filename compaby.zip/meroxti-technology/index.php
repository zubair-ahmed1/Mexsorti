<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle = 'MEROXTI TECHNOLOGY | Digital Solutions That Move You Forward';
$pageDescription = 'MEROXTI TECHNOLOGY builds modern websites, custom software, AI solutions, and mobile applications for ambitious businesses.';
$canonicalUrl = 'https://example.com/';
$activePage = 'home';

// ✅ FIX: Dynamic base path — koi hardcoded %20 nahi
$siteBase = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
if ($siteBase === '' || $siteBase === '.') {
    $siteBase = '';
}

// Safe Database Connection Include
if (file_exists(__DIR__ . '/config/database.php')) {
    require_once __DIR__ . '/config/database.php';
} elseif (file_exists(__DIR__ . '/config/dataphase.php')) {
    require_once __DIR__ . '/config/dataphase.php';
} elseif (file_exists(__DIR__ . '/includes/db.php')) {
    require_once __DIR__ . '/includes/db.php';
} else {
    $dbHost = '127.0.0.1';
    $dbName = 'meroxti_technology';
    $dbUser = 'root';
    $dbPass = '';
    try {
        $pdo = new PDO("mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4", $dbUser, $dbPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } catch (Exception $e) {
        $pdo = null;
    }
}

// Fetch Services from Database
$services = [];
try {
    if (isset($pdo) && $pdo) {
        $stmt = $pdo->query("SELECT * FROM services WHERE status = 'published' ORDER BY id ASC LIMIT 4");
        $dbServices = $stmt->fetchAll();

        if (!empty($dbServices)) {
            $icons = ['⌘', '▣', '✳', '▱'];
            $tags  = ['Web experiences', 'Built for scale', 'Intelligent systems', 'Mobile-first'];
            foreach ($dbServices as $index => $svc) {
                $services[] = [
                    'number' => str_pad((string)($index + 1), 2, '0', STR_PAD_LEFT),
                    'icon'   => $icons[$index % count($icons)],
                    'title'  => $svc['title'],
                    'text'   => $svc['short_description'] ?? 'Professional digital solution built for growth.',
                    'link'   => 'services/' . ($svc['slug'] ?? 'web-development.php'),
                    'tag'    => $tags[$index % count($tags)],
                ];
            }
        }
    }
} catch (Exception $e) {
    $services = [];
}

// Fallback Default Services
if (empty($services)) {
    $services = [
        [
            'number' => '01',
            'icon'   => '⌘',
            'title'  => 'Web Development',
            'text'   => 'Fast, responsive, search-friendly websites designed around your business goals.',
            'link'   => 'services/web-development.php',
            'tag'    => 'Web experiences',
        ],
        [
            'number' => '02',
            'icon'   => '▣',
            'title'  => 'Software Development',
            'text'   => 'Custom platforms and business tools that simplify complex workflows.',
            'link'   => 'services/software-development.php',
            'tag'    => 'Built for scale',
        ],
        [
            'number' => '03',
            'icon'   => '✳',
            'title'  => 'AI Solutions',
            'text'   => 'Practical AI integrations that help teams work smarter and move faster.',
            'link'   => 'services/ai-solutions.php',
            'tag'    => 'Intelligent systems',
        ],
        [
            'number' => '04',
            'icon'   => '▱',
            'title'  => 'Mobile App Development',
            'text'   => 'Thoughtful mobile experiences for customers on the move.',
            'link'   => 'services/mobile-app-development.php',
            'tag'    => 'Mobile-first',
        ],
    ];
}

function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <?php
    if (file_exists(__DIR__ . '/includes/seo.php')) {
        require __DIR__ . '/includes/seo.php';
    }
    ?>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- ✅ FIXED CSS PATH -->
    <link rel="stylesheet" href="<?= e($siteBase) ?>/assets/css/style.css">
</head>

<body>
<a class="skip-link" href="#main-content">Skip to content</a>

<?php
if (file_exists(__DIR__ . '/includes/navbar.php')) {
    require __DIR__ . '/includes/navbar.php';
}
?>

<main id="main-content">

    <!-- HERO SECTION -->
    <section class="hero section-shell">
        <div class="hero-grid" aria-hidden="true"></div>

        <div class="hero-copy reveal">
            <div class="eyebrow">
                <span class="status-dot"></span>
                DIGITAL INNOVATION PARTNER
            </div>

            <h1>
                Ideas into
                <span class="gradient-text">digital impact.</span>
            </h1>

            <p class="hero-lead">
                We design and build digital products that help ambitious
                businesses grow, operate smarter, and stand out online.
            </p>

            <div class="hero-actions">
                <a class="btn btn-primary-custom" href="<?= e($siteBase) ?>/contact.php">
                    Start a project <span aria-hidden="true">↗</span>
                </a>

                <a class="text-link" href="<?= e($siteBase) ?>/services.php">
                    Explore our services <span aria-hidden="true">→</span>
                </a>
            </div>

            <div class="hero-proof">
                <div class="proof-avatars" aria-hidden="true">
                    <span>M</span>
                    <span>T</span>
                    <span>+</span>
                </div>

                <div>
                    <strong>Technology with purpose</strong>
                    <small>Strategy · Design · Development</small>
                </div>
            </div>
        </div>

        <div class="hero-visual reveal" aria-label="Digital technology illustration">
            <div class="visual-glow"></div>

            <div class="orbit orbit-one"></div>
            <div class="orbit orbit-two"></div>
            <div class="orbit orbit-three"></div>

            <div class="visual-core">
                <div class="core-mark">M<span>.</span></div>
                <small>BUILD WHAT'S NEXT</small>
            </div>

            <div class="float-card card-code">
                <span class="mini-icon">⌘</span>
                <div>
                    <b>Clean code</b>
                    <small>Made to scale</small>
                </div>
                <span class="card-check">✓</span>
            </div>

            <div class="float-card card-ai">
                <span class="ai-spark">✳</span>
                <div>
                    <b>AI-powered</b>
                    <small>Smarter workflows</small>
                </div>
            </div>

            <div class="visual-caption">
                <span></span>
                Thoughtful technology. Measurable progress.
            </div>
        </div>
    </section>

    <!-- TRUST STRIP -->
    <section class="trust-strip">
        <div class="section-shell trust-inner">
            <span>YOUR PARTNER FOR</span>
            <strong>WEB</strong><i></i>
            <strong>SOFTWARE</strong><i></i>
            <strong>AI</strong><i></i>
            <strong>MOBILE</strong><i></i>
            <strong>GROWTH</strong>
        </div>
    </section>

    <!-- SERVICES -->
    <section class="section-shell section-pad" id="services">
        <div class="section-heading reveal">
            <div>
                <div class="eyebrow">WHAT WE DO</div>
                <h2>
                    Technology that
                    <span class="gradient-text">works for you.</span>
                </h2>
            </div>

            <p>
                From the first idea to the final launch, we turn business
                challenges into reliable digital experiences.
            </p>
        </div>

        <div class="service-grid">
            <?php foreach ($services as $i => $service): ?>
                <article
                    class="service-card reveal"
                    style="--card-delay: <?= (int) $i * 90 ?>ms"
                >
                    <div class="service-card-top">
                        <span class="service-icon">
                            <?= e($service['icon']) ?>
                        </span>

                        <span class="service-number">
                            <?= e($service['number']) ?>
                        </span>
                    </div>

                    <div class="service-tag">
                        <?= e($service['tag']) ?>
                    </div>

                    <h3><?= e($service['title']) ?></h3>

                    <p><?= e($service['text']) ?></p>

                    <a
                        class="card-link"
                        href="<?= e($siteBase . '/' . $service['link']) ?>"
                    >
                        Explore service <span>↗</span>
                    </a>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- ABOUT -->
    <section class="about-band">
        <div class="section-shell about-grid">

            <div class="about-graphic reveal">
                <div class="graphic-ring ring-a"></div>
                <div class="graphic-ring ring-b"></div>

                <div class="graphic-center">MX<span>®</span></div>

                <div class="graphic-chip chip-top">DESIGN</div>
                <div class="graphic-chip chip-bottom">ENGINEER</div>
            </div>

            <div class="about-copy reveal">
                <div class="eyebrow">WHY MEROXTI</div>

                <h2>
                    Good technology should make business
                    <span class="gradient-text">feel simpler.</span>
                </h2>

                <p>
                    We combine thoughtful planning, clean development,
                    and a focus on real user needs to create digital
                    solutions that are useful today and ready for tomorrow.
                </p>

                <ul class="check-list">
                    <li><span>✓</span> Clear communication from start to launch</li>
                    <li><span>✓</span> Responsive, accessible user experiences</li>
                    <li><span>✓</span> Maintainable code and performance-minded builds</li>
                    <li><span>✓</span> SEO-ready foundations from day one</li>
                </ul>

                <a class="btn btn-outline-custom" href="<?= e($siteBase) ?>/about.php">
                    Get to know us <span>→</span>
                </a>
            </div>
        </div>
    </section>

    <!-- PROCESS -->
    <section class="section-shell section-pad">
        <div class="section-heading reveal">
            <div>
                <div class="eyebrow">HOW WE WORK</div>
                <h2>
                    A clear path from
                    <span class="gradient-text">idea to launch.</span>
                </h2>
            </div>

            <p>
                A collaborative process that keeps priorities visible
                and progress moving.
            </p>
        </div>

        <div class="process-grid">
            <article class="process-step reveal">
                <span>01</span>
                <div class="process-line"></div>
                <h3>Discover</h3>
                <p>Understand your goals, audience, and requirements.</p>
            </article>

            <article class="process-step reveal">
                <span>02</span>
                <div class="process-line"></div>
                <h3>Plan &amp; design</h3>
                <p>Map the solution and shape a clear user experience.</p>
            </article>

            <article class="process-step reveal">
                <span>03</span>
                <div class="process-line"></div>
                <h3>Build</h3>
                <p>Develop, review, and refine the product in stages.</p>
            </article>

            <article class="process-step reveal">
                <span>04</span>
                <div class="process-line"></div>
                <h3>Launch &amp; improve</h3>
                <p>Test carefully and plan for ongoing improvements.</p>
            </article>
        </div>
    </section>

    <!-- CALL TO ACTION -->
    <section class="section-shell section-pad project-preview">
        <div class="project-panel reveal">
            <div class="project-panel-copy">
                <div class="eyebrow">LET'S BUILD SOMETHING BETTER</div>

                <h2>
                    Your next big idea deserves
                    <span class="gradient-text">a strong digital foundation.</span>
                </h2>

                <p>
                    Tell us what you're working on. We'll help you explore
                    the right path forward.
                </p>

                <a class="btn btn-primary-custom" href="<?= e($siteBase) ?>/contact.php">
                    Discuss your project <span>↗</span>
                </a>
            </div>

            <div class="project-orb" aria-hidden="true">
                <div class="orb-inner">MX</div>
                <span class="orb-label label-one">STRATEGY</span>
                <span class="orb-label label-two">TECHNOLOGY</span>
                <span class="orb-label label-three">GROWTH</span>
            </div>
        </div>
    </section>

</main>

<?php
if (file_exists(__DIR__ . '/includes/footer.php')) {
    require __DIR__ . '/includes/footer.php';
}
?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const animatedItems = document.querySelectorAll('.reveal');

    if (!('IntersectionObserver' in window)) {
        animatedItems.forEach(function (item) {
            item.classList.add('active');
        });
        return;
    }

    const observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.08
    });

    animatedItems.forEach(function (item) {
        observer.observe(item);
    });
});
</script>

</body>
</html>