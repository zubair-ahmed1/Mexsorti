<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$siteBase = '  /meroxti-technology-starter/meroxti-technology';
$currentActive = $activePage ?? 'home';
?>
<header class="navbar navbar-expand-lg">
    <div class="section-shell navbar-container">
        <!-- Modern Professional Logo Symbol instead of plain text -->
        <a class="navbar-brand brand-lockup" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/index.php" aria-label="MEROXTI TECHNOLOGY Home">
            <span class="brand-logo-badge">
                <span class="brand-letter">M</span><span class="brand-dot">.</span>
            </span>
            <div class="brand-text-wrap">
                <span class="brand-title">MEROXTI</span>
                <small class="brand-subtitle">TECHNOLOGY</small>
            </div>
        </a>

        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNavbarNav" aria-controls="mainNavbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <nav class="collapse navbar-collapse justify-content-end" id="mainNavbarNav">
            <ul class="navbar-nav align-items-lg-center gap-lg-2">
                <li class="nav-item">
                    <a class="nav-link <?= $currentActive === 'home' ? 'active' : '' ?>" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/index.php">Home</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $currentActive === 'about' ? 'active' : '' ?>" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/about.php">About</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $currentActive === 'services' ? 'active' : '' ?>" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/services.php">Services</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $currentActive === 'projects' ? 'active' : '' ?>" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/projects.php">Projects</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link <?= $currentActive === 'blog' ? 'active' : '' ?>" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/blog.php">Insights</a>
                </li>
                <li class="nav-item ms-lg-3">
                    <a class="btn btn-primary-custom nav-cta-btn" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Let's Talk <span aria-hidden="true">↗</span>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</header>