<footer class="site-footer">
    <div class="section-shell footer-clean-wrapper">
        <p class="footer-copy-text">© <?= date('Y') ?> <strong>MEROXTI TECHNOLOGY</strong>. All rights reserved.</p>
        
        <nav class="footer-nav-links" aria-label="Footer Navigation">
            <a href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/about.php">About</a>
            <a href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/services.php">Services</a>
            <a href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/projects.php">Projects</a>
            <a href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">Contact</a>
            <a href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/privacy-policy.php">Privacy</a>
        </nav>

        <a class="back-to-top" href="#top" onclick="window.scrollTo({top:0,behavior:'smooth'});return false;">Top ↑</a>
    </div>
</footer>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/assets/js/main.js"></script>
</body>
</html>