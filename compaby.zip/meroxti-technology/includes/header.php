<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Global Site Path Detect
$appDir = dirname(__DIR__);
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$siteBase = rtrim($scriptDir, '/');
if (basename($siteBase) === 'services' || basename($siteBase) === 'actions') {
    $siteBase = dirname($siteBase);
}
if ($siteBase === '/' || $siteBase === '\\') {
    $siteBase = '';
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title><?= isset($pageTitle) ? htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') : 'MEROXTI TECHNOLOGY' ?></title>

    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">

    <!-- Root Path CSS Fix -->
    <link rel="stylesheet" href="<?= $siteBase ?>/assets/css/style.css?v=3.0">
</head>
<body>
<a class="skip-link" href="#main-content">Skip to content</a>