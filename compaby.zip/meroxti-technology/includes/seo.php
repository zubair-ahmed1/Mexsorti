<?php
// Set $pageTitle, $pageDescription and optionally $canonicalUrl before including header.php.
$pageTitle = $pageTitle ?? 'MEROXTI TECHNOLOGY | Digital Solutions';
$pageDescription = $pageDescription ?? 'Web development, software development, AI solutions, and mobile applications for modern businesses.';
$canonicalUrl = $canonicalUrl ?? '';
$metaRobots = $metaRobots ?? 'index, follow';
?>
<title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></title>
<meta name="description" content="<?= htmlspecialchars($pageDescription, ENT_QUOTES, 'UTF-8') ?>">
<meta name="robots" content="<?= htmlspecialchars($metaRobots, ENT_QUOTES, 'UTF-8') ?>">
<?php if ($canonicalUrl !== ''): ?>
<link rel="canonical" href="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>">
<?php endif; ?>
<meta property="og:type" content="website">
<meta property="og:site_name" content="MEROXTI TECHNOLOGY">
<meta property="og:title" content="<?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?>">
<meta property="og:description" content="<?= htmlspecialchars($pageDescription, ENT_QUOTES, 'UTF-8') ?>">
<?php if ($canonicalUrl !== ''): ?>
<meta property="og:url" content="<?= htmlspecialchars($canonicalUrl, ENT_QUOTES, 'UTF-8') ?>">
<?php endif; ?>
<meta name="twitter:card" content="summary_large_image">
<meta name="theme-color" content="#080b16">
