<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle = 'About Us | MEROXTI TECHNOLOGY';
$pageDescription = 'Meet the executive leadership team at MEROXTI TECHNOLOGY turning ambitious ideas into digital reality.';
$canonicalUrl = '';
$activePage = 'about';

// ✅ FIXED: Dynamic site base path (auto-detect folder)
$siteBase = rtrim(dirname($_SERVER['SCRIPT_NAME']), '/\\');
if ($siteBase === '' || $siteBase === '.' || $siteBase === '/') {
    $siteBase = '';
}

// Include database connection safely
if (file_exists(__DIR__ . '/config/database.php')) {
    require_once __DIR__ . '/config/database.php';
} elseif (file_exists(__DIR__ . '/config/dataphase.php')) {
    require_once __DIR__ . '/config/dataphase.php';
} elseif (file_exists(__DIR__ . '/includes/db.php')) {
    require_once __DIR__ . '/includes/db.php';
} else {
    $dbHost = '127.0.0.1';
    $dbName = 'meroxti_technology';
    $dbUser = 'root';
    $dbPass = '';
    try {
        $pdo = new PDO("mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4", $dbUser, $dbPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } catch (Exception $e) {
        $pdo = null;
    }
}

// Leadership Team Data with exact folder path (`assets/imges/`)
$leadershipTeam = [
    [
        'name' => 'ZUBAIR AHMED',
        'role' => 'Chief Executive Officer (CEO)',
        'bio' => 'Driving the overall vision, technological strategy, and global growth of MEROXTI TECHNOLOGY.',
        'image' => $siteBase . '/assets/imges/zubair.jpeg'
    ],
    [
        'name' => 'ABDUL SALLAM',
        'role' => 'Chief Marketing Officer (CMO)',
        'bio' => 'Leading brand positioning, strategic partnerships, and market expansion across digital ecosystems.',
        'image' => $siteBase . '/assets/imges/salam.jpeg'
    ],
    [
        'name' => 'MAHMMED IBRAHIM',
        'role' => 'Chief Operating Officer (COO)',
        'bio' => 'Overseeing day-to-day operations, project execution workflows, and client delivery standards.',
        'image' => $siteBase . '/assets/imges/ibrahim.jpeg'
    ],
    [
        'name' => 'SAFIULLAH',
        'role' => 'Lead Technology Architect',
        'bio' => 'Architecting robust full-stack systems, scalable applications, and advanced digital infrastructure.',
        'image' => $siteBase . '/assets/imges/safillah.jpeg'
    ]
];

// Include Header & Navbar
require __DIR__ . '/includes/header.php';
require __DIR__ . '/includes/navbar.php';
?>

<main id="main-content">
    <!-- ABOUT HERO SECTION -->
    <section class="about-hero-section section-shell section-pad">
        <div class="about-hero-copy reveal">
            <div class="eyebrow">
                <span class="status-dot"></span>
                ABOUT MEROXTI TECHNOLOGY
            </div>
            <h1>
                Technology built with
                <span class="gradient-text">purpose and passion.</span>
            </h1>
            <p class="hero-lead">
                We combine deep technical engineering, creative UI/UX design, and strategic business vision 
                to create robust digital products that empower ambitious companies.
            </p>
            <div class="hero-actions">
                <a class="btn btn-primary-custom" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                    Start a conversation <span aria-hidden="true">↗</span>
                </a>
                <a class="text-link" href="#team-section">
                    Meet our leadership <span aria-hidden="true">↓</span>
                </a>
            </div>
        </div>

        <!-- VIP Floating Cards for Excellence & Support -->
        <div class="about-hero-visual reveal" aria-hidden="true">
            <div class="visual-glow"></div>
            <div class="vip-about-stat-card">
                <div class="stat-icon-badge">★</div>
                <div class="stat-content">
                    <strong>100%</strong>
                    <span>Committed to Excellence</span>
                </div>
            </div>
            <div class="vip-about-stat-card card-offset">
                <div class="stat-icon-badge">⚡</div>
                <div class="stat-content">
                    <strong>24/7</strong>
                    <span>Reliable Support & Scale</span>
                </div>
            </div>
        </div>
    </section>

    <!-- MISSION & VISION VIP CARDS SECTION -->
    <section class="section-shell section-pad">
        <div class="section-heading reveal">
            <div>
                <div class="eyebrow">OUR CORE PRINCIPLES</div>
                <h2>
                    Driven by purpose,
                    <span class="gradient-text">defined by vision.</span>
                </h2>
            </div>
            <p>
                The foundational pillars that guide our engineering standards and corporate culture.
            </p>
        </div>

        <div class="vip-mission-grid">
            <!-- Mission Card -->
            <article class="vip-principle-card reveal">
                <div class="card-glow-accent"></div>
                <div class="principle-icon-wrap">🎯</div>
                <span class="principle-tag">Our Mission</span>
                <h3>Empowering Business Growth</h3>
                <p>To engineer world-class software, web platforms, and digital solutions that simplify complex workflows and accelerate business growth.</p>
            </article>

            <!-- Vision Card -->
            <article class="vip-principle-card reveal" style="--card-delay: 150ms;">
                <div class="card-glow-accent"></div>
                <div class="principle-icon-wrap">🚀</div>
                <span class="principle-tag">Our Vision</span>
                <h3>Global Digital Leadership</h3>
                <p>To be the most trusted global partner for cutting-edge digital transformation, combining AI, design precision, and reliable code.</p>
            </article>
        </div>
    </section>

    <!-- EXECUTIVE LEADERSHIP TEAM SECTION -->
    <section class="section-shell section-pad" id="team-section">
        <div class="section-heading reveal">
            <div>
                <div class="eyebrow">EXECUTIVE LEADERSHIP</div>
                <h2>
                    The minds behind
                    <span class="gradient-text">our innovation.</span>
                </h2>
            </div>
            <p>
                A seasoned team of technologists, strategists, and leaders dedicated to delivering exceptional digital outcomes.
            </p>
        </div>

        <div class="team-grid">
            <?php foreach ($leadershipTeam as $index => $member): ?>
                <article class="team-card reveal" style="--card-delay: <?= (int)$index * 100 ?>ms">
                    <div class="team-img-wrapper">
                        <img 
                            src="<?= htmlspecialchars($member['image'], ENT_QUOTES, 'UTF-8') ?>" 
                            alt="<?= htmlspecialchars($member['name'], ENT_QUOTES, 'UTF-8') ?>"
                            onerror="this.src='data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\' width=\'300\' height=\'350\' viewBox=\'0 0 300 350\'><rect width=\'300\' height=\'350\' fill=\'%231e293b\'/><text x=\'50%\' y=\'50%\' dominant-baseline=\'middle\' text-anchor=\'middle\' fill=\'%2394a3b8\' font-family=\'sans-serif\' font-size=\'16\'>Team Member Photo</text></svg>'"
                            loading="lazy"
                        >
                        <div class="team-overlay-badge">MX</div>
                    </div>

                    <div class="team-info">
                        <h3><?= htmlspecialchars($member['name'], ENT_QUOTES, 'UTF-8') ?></h3>
                        <span class="team-role"><?= htmlspecialchars($member['role'], ENT_QUOTES, 'UTF-8') ?></span>
                        <p><?= htmlspecialchars($member['bio'], ENT_QUOTES, 'UTF-8') ?></p>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- DATABASE SCHEMA INTEGRATION NOTICE -->
    <section class="db-notice-band">
        <div class="section-shell">
            <div class="db-notice-box reveal">
                <span class="db-tag">DATABASE INFRASTRUCTURE (`meroxti_technology`)</span>
                <h4>Enterprise-Grade Security & Data Management</h4>
                <p>Our platform architecture is backed by a fully structured MySQL relational database featuring normalized tables for services, portfolio projects, blog categories, inquiries, and secure administrative access controls.</p>
            </div>
        </div>
    </section>
</main>

<?php require __DIR__ . '/includes/footer.php'; ?>

<!-- Scroll Animation Script -->
<script>
document.addEventListener('DOMContentLoaded', function () {
    const animatedItems = document.querySelectorAll('.reveal');

    if (!('IntersectionObserver' in window)) {
        animatedItems.forEach(function (item) {
            item.classList.add('active');
        });
        return;
    }

    const observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1
    });

    animatedItems.forEach(function (item) {
        observer.observe(item);
    });
});
</script>