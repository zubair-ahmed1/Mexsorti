<?php
http_response_code(501);
$pageTitle = 'Admin Dashboard | MEROXTI TECHNOLOGY';
$pageDescription = 'Administrator dashboard placeholder.';
$metaRobots = 'noindex, nofollow';
$canonicalUrl = '';
require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/navbar.php';
?>
<main class="section-shell section-pad"><div class="eyebrow">ADMIN AREA</div><h1 class="page-title">Dashboard setup required</h1><p class="page-intro">This page is a placeholder. Add session-based authentication and authorization before displaying private data.</p></main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
