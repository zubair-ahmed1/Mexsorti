<?php
$pageTitle = 'Admin Login | MEROXTI TECHNOLOGY';
$pageDescription = 'Administrator sign in.';
$metaRobots = 'noindex, nofollow';
$canonicalUrl = '';
require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/navbar.php';
?>
<main class="section-shell section-pad"><div class="eyebrow">ADMIN AREA</div><h1 class="page-title">Admin login</h1><p class="page-intro">The admin authentication flow must be configured before this area is used.</p><p class="page-intro">For security, create a password-hashed admin account and verify credentials with PDO before enabling dashboard access.</p></main>
<?php require __DIR__ . '/../includes/footer.php'; ?>
