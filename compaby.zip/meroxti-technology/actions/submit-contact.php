<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: ../contact.php');
    exit;
}

if (!isset($_POST['csrf_token']) || !isset($_SESSION['csrf_token']) || !hash_equals($_SESSION['csrf_token'], $_POST['csrf_token'])) {
    die('Security validation failed. Please go back and try again.');
}

$name    = trim($_POST['name'] ?? '');
$email   = filter_var(trim($_POST['email'] ?? ''), FILTER_SANITIZE_EMAIL);
$phone   = trim($_POST['phone'] ?? '');
$service = trim($_POST['service'] ?? 'General Inquiry');
$message = trim($_POST['message'] ?? '');

if (empty($name) || empty($email) || empty($message) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header('Location: ../contact.php?error=invalid_input');
    exit;
}

// Database Storage
$pdo = null;
if (file_exists(__DIR__ . '/../config/database.php')) {
    require_once __DIR__ . '/../config/database.php';
} else {
    try {
        $pdo = new PDO("mysql:host=127.0.0.1;dbname=meroxti_technology;charset=utf8mb4", 'root', '', [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        ]);
    } catch (Exception $e) {
        $pdo = null;
    }
}

if ($pdo) {
    try {
        $stmt = $pdo->prepare("INSERT INTO inquiries (name, email, phone, service, message, created_at) VALUES (:name, :email, :phone, :service, :message, NOW())");
        $stmt->execute([
            ':name'    => $name,
            ':email'   => $email,
            ':phone'   => $phone,
            ':service' => $service,
            ':message' => $message
        ]);
    } catch (Exception $e) {}
}

// 📧 Gmail SMTP / Mail Simulation Setup
$toEmail = 'meroxtitec@gmail.com';
$emailSubject = 'New Enterprise Inquiry from ' . $name;

$emailBody = "Name: {$name}\n";
$emailBody .= "Email: {$email}\n";
$emailBody .= "Phone: {$phone}\n";
$emailBody .= "Service: {$service}\n\n";
$emailBody .= "Message:\n{$message}\n";

$headers  = "From: meroxtitec@gmail.com\r\n";
$headers .= "Reply-To: {$email}\r\n";
$headers .= "X-Mailer: PHP/" . phpversion();

// Try sending via mail (works if XAMPP sendmail is configured, otherwise database & WhatsApp catch it)
@mail($toEmail, $emailSubject, $emailBody, $headers);

// WhatsApp Redirect Link (+923413797541)
$whatsappNumber = '923413797541';
$whatsappText = urlencode("Hello MEROXTI TECHNOLOGY,\n\nName: *{$name}*\nEmail: {$email}\nService: {$service}\n\nMessage:\n{$message}");
$whatsappUrl = "https://wa.me/{$whatsappNumber}?text={$whatsappText}";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Inquiry Success | MEROXTI TECHNOLOGY</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body style="display: grid; place-items: center; min-height: 100vh; text-align: center; padding: 20px;">
    <div style="max-width: 550px; width: 100%; padding: 40px; border: 1px solid var(--border); border-radius: 20px; background: rgba(30, 41, 59, 0.9);">
        <div style="font-size: 3rem; color: #34d399; margin-bottom: 15px;">✓</div>
        <h2 style="color: #fff; margin-bottom: 10px;">Message Sent Successfully!</h2>
        <p style="color: var(--muted); margin-bottom: 25px;">
            Thank you, <strong><?= htmlspecialchars($name) ?></strong>. Your inquiry has been saved successfully.
        </p>
        <div style="display: flex; gap: 15px; justify-content: center; flex-wrap: wrap;">
            <a href="<?= $whatsappUrl ?>" class="btn btn-primary-custom" target="_blank" style="background: #25d366; border-color: #25d366; color: #fff;">
                Open WhatsApp Chat 💬
            </a>
            <a href="../index.php" class="btn btn-outline-custom">
                Home Page →
            </a>
        </div>
    </div>
</body>
</html>