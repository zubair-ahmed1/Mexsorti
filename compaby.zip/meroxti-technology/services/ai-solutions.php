<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle = 'AI Solutions | MEROXTI TECHNOLOGY';
$pageDescription = 'Practical AI integrations that support useful, responsible business workflows and accelerate enterprise velocity.';
$canonicalUrl = '';
$activePage = 'services';

// Absolute base path resolution for root links
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$siteBase = rtrim(dirname($scriptDir), '/');
if ($siteBase === '.' || $siteBase === '/' || $siteBase === '\\') {
    $siteBase = '';
}

function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<main id="main-content">

    <!-- HERO SECTION -->
    <section class="ai-hero-section section-shell section-pad">
        <div class="ai-hero-copy reveal">
            <div class="eyebrow">
                <span class="status-dot"></span>
                INTELLIGENT SYSTEMS
            </div>
            <h1>
                Practical AI that
                <span class="gradient-text">moves your business forward.</span>
            </h1>
            <p class="hero-lead">
                We integrate responsible AI solutions that automate workflows, 
                unlock insights from data, and help teams work smarter — not harder.
            </p>
            <div class="hero-actions">
                <a class="btn btn-primary-custom" href="<?= e($siteBase) ?>/contact.php">
                    Discuss your project <span aria-hidden="true">↗</span>
                </a>
                <a class="text-link" href="#ai-capabilities">
                    Explore capabilities <span aria-hidden="true">↓</span>
                </a>
            </div>
        </div>

        <div class="ai-hero-visual reveal" aria-hidden="true">
            <div class="visual-glow"></div>

            <div class="ai-core">
                <div class="ai-core-inner">✳</div>
            </div>

            <div class="vip-floating-metric">
                <span class="metric-num">10x</span>
                <span class="metric-txt">Workflow Acceleration</span>
            </div>

            <div class="vip-floating-metric metric-two">
                <span class="metric-num">24/7</span>
                <span class="metric-txt">Autonomous Processing</span>
            </div>
        </div>
    </section>

    <!-- AI CAPABILITIES GRID -->
    <section class="section-shell section-pad" id="ai-capabilities">
        <div class="section-heading reveal">
            <div>
                <div class="eyebrow">AI CAPABILITIES</div>
                <h2>
                    Intelligent systems built for
                    <span class="gradient-text">real business outcomes.</span>
                </h2>
            </div>
            <p>
                From custom machine learning models to conversational interfaces — we build AI that delivers measurable value.
            </p>
        </div>

        <div class="vip-service-grid">
            <article class="vip-service-card reveal">
                <div class="card-top-row">
                    <span class="card-index">01</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>Machine Learning Models</h3>
                <p>Custom-trained models for prediction, classification, and pattern recognition tailored to your domain data.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">Python · TensorFlow</span>
                    <a class="card-link" href="<?= e($siteBase) ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 100ms;">
                <div class="card-top-row">
                    <span class="card-index">02</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>Intelligent Chatbots</h3>
                <p>Conversational AI assistants that handle customer support, lead qualification, and internal helpdesk tasks.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">NLP · LLMs</span>
                    <a class="card-link" href="<?= e($siteBase) ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 200ms;">
                <div class="card-top-row">
                    <span class="card-index">03</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>Automation Pipelines</h3>
                <p>End-to-end workflow automation that eliminates repetitive tasks and frees your team for high-value work.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">RPA · APIs</span>
                    <a class="card-link" href="<?= e($siteBase) ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>
        </div>
    </section>

</main>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const animatedItems = document.querySelectorAll('.reveal');
    animatedItems.forEach(function (item) {
        item.classList.add('active');
    });
});
</script>