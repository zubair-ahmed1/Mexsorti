<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle = 'Mobile App Development | MEROXTI TECHNOLOGY';
$pageDescription = 'Mobile applications designed around the needs of your users and business — built for iOS, Android, and cross-platform performance.';
$canonicalUrl = '';
$activePage = 'services';

// ✅ FIXED: Dynamic site base path (auto-detect folder)
$siteBase = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/\\');
if ($siteBase === '' || $siteBase === '.' || $siteBase === '/') {
    $siteBase = '';
}

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/navbar.php';
?>

<main id="main-content">

    <!-- HERO SECTION -->
    <section class="ai-hero-section section-shell section-pad">
        <div class="ai-hero-copy reveal">
            <div class="eyebrow">
                <span class="status-dot"></span>
                MOBILE EXPERIENCES
            </div>
            <h1>
                Mobile apps that
                <span class="gradient-text">users love to open.</span>
            </h1>
            <p class="hero-lead">
                We design and build smooth, high-performance mobile applications 
                for iOS and Android — engineered around real user behavior and business goals.
            </p>
            <div class="hero-actions">
                <a class="btn btn-primary-custom" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                    Discuss your app <span aria-hidden="true">↗</span>
                </a>
                <a class="text-link" href="#mobile-capabilities">
                    Explore capabilities <span aria-hidden="true">↓</span>
                </a>
            </div>
        </div>

        <div class="ai-hero-visual reveal" aria-hidden="true">
            <div class="visual-glow"></div>

            <div class="ai-core">
                <div class="ai-core-inner">▱</div>
            </div>

            <div class="vip-floating-metric">
                <span class="metric-num">4.9★</span>
                <span class="metric-txt">Average Store Rating</span>
            </div>

            <div class="vip-floating-metric metric-two">
                <span class="metric-num">60fps</span>
                <span class="metric-txt">Smooth UI Performance</span>
            </div>
        </div>
    </section>

    <!-- MOBILE CAPABILITIES GRID -->
    <section class="section-shell section-pad" id="mobile-capabilities">
        <div class="section-heading reveal">
            <div>
                <div class="eyebrow">MOBILE CAPABILITIES</div>
                <h2>
                    Built for users,
                    <span class="gradient-text">engineered for scale.</span>
                </h2>
            </div>
            <p>
                From native iOS and Android apps to cross-platform solutions — we deliver mobile experiences that feel right.
            </p>
        </div>

        <div class="vip-service-grid">
            <article class="vip-service-card reveal">
                <div class="card-top-row">
                    <span class="card-index">01</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>Native iOS Development</h3>
                <p>Swift-based applications built for Apple's ecosystem — smooth, secure, and App Store ready.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">Swift · SwiftUI</span>
                    <a class="card-link" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 100ms;">
                <div class="card-top-row">
                    <span class="card-index">02</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>Native Android Development</h3>
                <p>Kotlin-powered apps engineered for performance, battery efficiency, and Play Store compliance.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">Kotlin · Jetpack</span>
                    <a class="card-link" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 200ms;">
                <div class="card-top-row">
                    <span class="card-index">03</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>Cross-Platform Apps</h3>
                <p>One codebase, two platforms — Flutter and React Native apps that deliver near-native performance.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">Flutter · React Native</span>
                    <a class="card-link" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 300ms;">
                <div class="card-top-row">
                    <span class="card-index">04</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>Mobile UI/UX Design</h3>
                <p>User-centered interfaces with smooth interactions, clear flows, and pixel-perfect visual details.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">Figma · Prototyping</span>
                    <a class="card-link" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 400ms;">
                <div class="card-top-row">
                    <span class="card-index">05</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>API &amp; Backend Integration</h3>
                <p>Secure connections to your existing systems — REST, GraphQL, real-time sockets, and offline sync.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">REST · GraphQL</span>
                    <a class="card-link" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 500ms;">
                <div class="card-top-row">
                    <span class="card-index">06</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>App Store Deployment</h3>
                <p>End-to-end publishing support — review prep, screenshots, metadata, and post-launch monitoring.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">App Store · Play Store</span>
                    <a class="card-link" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>
        </div>
    </section>

    <!-- PROCESS SECTION -->
    <section class="section-shell section-pad">
        <div class="section-heading reveal">
            <div>
                <div class="eyebrow">HOW WE BUILD APPS</div>
                <h2>
                    From idea to app store —
                    <span class="gradient-text">a clear path.</span>
                </h2>
            </div>
            <p>
                A collaborative mobile-first methodology that keeps your users at the center of every decision.
            </p>
        </div>

        <div class="process-grid">
            <article class="process-step reveal">
                <span>01</span>
                <div class="process-line"></div>
                <h3>Discover</h3>
                <p>Understand user needs, business goals, and platform requirements.</p>
            </article>

            <article class="process-step reveal">
                <span>02</span>
                <div class="process-line"></div>
                <h3>Design</h3>
                <p>Wireframes, prototypes, and polished UI flows ready for development.</p>
            </article>

            <article class="process-step reveal">
                <span>03</span>
                <div class="process-line"></div>
                <h3>Build &amp; Test</h3>
                <p>Develop in sprints with rigorous QA on real devices.</p>
            </article>

            <article class="process-step reveal">
                <span>04</span>
                <div class="process-line"></div>
                <h3>Launch &amp; Grow</h3>
                <p>Publish to app stores, monitor analytics, and iterate with updates.</p>
            </article>
        </div>
    </section>

    <!-- CALL TO ACTION -->
    <section class="section-shell section-pad project-preview">
        <div class="project-panel reveal">
            <div class="project-panel-copy">
                <div class="eyebrow">LET'S BUILD YOUR APP</div>
                <h2>
                    Have a mobile idea?
                    <span class="gradient-text">Let's make it real.</span>
                </h2>
                <p>
                    Talk to our mobile team and get a tailored plan for your iOS, Android, or cross-platform app.
                </p>
                <a class="btn btn-primary-custom" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                    Discuss your app <span>↗</span>
                </a>
            </div>

            <div class="project-orb" aria-hidden="true">
                <div class="orb-inner">APP</div>
                <span class="orb-label label-one">iOS</span>
                <span class="orb-label label-two">ANDROID</span>
                <span class="orb-label label-three">CROSS-PLATFORM</span>
            </div>
        </div>
    </section>

</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const animatedItems = document.querySelectorAll('.reveal');

    if (!('IntersectionObserver' in window)) {
        animatedItems.forEach(function (item) {
            item.classList.add('active');
        });
        return;
    }

    const observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1
    });

    animatedItems.forEach(function (item) {
        observer.observe(item);
    });
});
</script>