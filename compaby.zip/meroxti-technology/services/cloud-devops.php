<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle = 'Cloud & DevOps | MEROXTI TECHNOLOGY';
$pageDescription = 'Scalable cloud infrastructure, automated CI/CD pipelines, and robust DevOps solutions to ensure high availability and speed.';
$canonicalUrl = '';
$activePage = 'services';

// Absolute base path resolution for root links
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$siteBase = rtrim(dirname($scriptDir), '/');
if ($siteBase === '.' || $siteBase === '/' || $siteBase === '\\') {
    $siteBase = '';
}

function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<main id="main-content">

    <!-- HERO SECTION -->
    <section class="ai-hero-section section-shell section-pad">
        <div class="ai-hero-copy reveal">
            <div class="eyebrow">
                <span class="status-dot"></span>
                INFRASTRUCTURE &amp; RELIABILITY
            </div>
            <h1>
                Scalable cloud systems,
                <span class="gradient-text">automated for velocity.</span>
            </h1>
            <p class="hero-lead">
                We engineer robust cloud environments, streamlined CI/CD pipelines, and resilient infrastructure 
                that scale seamlessly with your enterprise growth.
            </p>
            <div class="hero-actions">
                <a class="btn btn-primary-custom" href="<?= e($siteBase) ?>/contact.php">
                    Optimize your infrastructure <span aria-hidden="true">↗</span>
                </a>
                <a class="text-link" href="#devops-capabilities">
                    Explore cloud services <span aria-hidden="true">↓</span>
                </a>
            </div>
        </div>

        <div class="ai-hero-visual reveal" aria-hidden="true">
            <div class="visual-glow"></div>

            <div class="ai-core">
                <div class="ai-core-inner">⚡</div>
            </div>

            <div class="vip-floating-metric">
                <span class="metric-num">99.9%</span>
                <span class="metric-txt">High Availability Uptime</span>
            </div>

            <div class="vip-floating-metric metric-two">
                <span class="metric-num">10x</span>
                <span class="metric-txt">Faster Deployments</span>
            </div>
        </div>
    </section>

    <!-- CLOUD & DEVOPS CAPABILITIES GRID -->
    <section class="section-shell section-pad" id="devops-capabilities">
        <div class="section-heading reveal">
            <div>
                <div class="eyebrow">CLOUD CAPABILITIES</div>
                <h2>
                    Enterprise infrastructure built for
                    <span class="gradient-text">security and scale.</span>
                </h2>
            </div>
            <p>
                From multi-cloud migration to automated container orchestration, we ensure your applications run reliably around the clock.
            </p>
        </div>

        <div class="vip-service-grid">
            <article class="vip-service-card reveal">
                <div class="card-top-row">
                    <span class="card-index">01</span>
                    <span class="card-status-badge">Core Service</span>
                </div>
                <h3>Cloud Architecture &amp; Migration</h3>
                <p>Design, deployment, and seamless migration of workloads across AWS, Microsoft Azure, and Google Cloud Platform.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">AWS · Azure · GCP</span>
                    <a class="card-link" href="<?= e($siteBase) ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 100ms;">
                <div class="card-top-row">
                    <span class="card-index">02</span>
                    <span class="card-status-badge">Core Service</span>
                </div>
                <h3>CI/CD Automation Pipelines</h3>
                <p>Automated build, test, and release workflows that accelerate software delivery while reducing human error.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">GitHub Actions · GitLab</span>
                    <a class="card-link" href="<?= e($siteBase) ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 200ms;">
                <div class="card-top-row">
                    <span class="card-index">03</span>
                    <span class="card-status-badge">Core Service</span>
                </div>
                <h3>Containerization &amp; Orchestration</h3>
                <p>Package applications with Docker and scale them efficiently across managed Kubernetes clusters for high availability.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">Docker · Kubernetes</span>
                    <a class="card-link" href="<?= e($siteBase) ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 300ms;">
                <div class="card-top-row">
                    <span class="card-index">04</span>
                    <span class="card-status-badge">Core Service</span>
                </div>
                <h3>Infrastructure as Code (IaC)</h3>
                <p>Provision and manage cloud resources declaratively with version control, ensuring consistency across environments.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">Terraform · Ansible</span>
                    <a class="card-link" href="<?= e($siteBase) ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 400ms;">
                <div class="card-top-row">
                    <span class="card-index">05</span>
                    <span class="card-status-badge">Core Service</span>
                </div>
                <h3>Monitoring &amp; Observability</h3>
                <p>Real-time telemetry, log aggregation, and proactive alerting to detect and resolve system bottlenecks instantly.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">Prometheus · Grafana</span>
                    <a class="card-link" href="<?= e($siteBase) ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 500ms;">
                <div class="card-top-row">
                    <span class="card-index">06</span>
                    <span class="card-status-badge">Core Service</span>
                </div>
                <h3>DevSecOps &amp; Compliance</h3>
                <p>Embed security best practices, automated vulnerability scanning, and compliance checks into every stage of development.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">Security · Hardening</span>
                    <a class="card-link" href="<?= e($siteBase) ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>
        </div>
    </section>

    <!-- CALL TO ACTION -->
    <section class="section-shell section-pad project-preview">
        <div class="project-panel reveal">
            <div class="project-panel-copy">
                <div class="eyebrow">LET'S SECURE YOUR INFRASTRUCTURE</div>
                <h2>
                    Ready to scale your cloud
                    <span class="gradient-text">with absolute confidence?</span>
                </h2>
                <p>
                    Talk to our cloud engineers and build a resilient infrastructure designed for high performance and uptime.
                </p>
                <a class="btn btn-primary-custom" href="<?= e($siteBase) ?>/contact.php">
                    Discuss your architecture <span>↗</span>
                </a>
            </div>

            <div class="project-orb" aria-hidden="true">
                <div class="orb-inner">OPS</div>
                <span class="orb-label label-one">SCALE</span>
                <span class="orb-label label-two">AUTOMATE</span>
                <span class="orb-label label-three">SECURE</span>
            </div>
        </div>
    </section>

</main>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const animatedItems = document.querySelectorAll('.reveal');
    animatedItems.forEach(function (item) {
        item.classList.add('active');
    });
});
</script>