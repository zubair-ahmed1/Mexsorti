<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle = 'Software Development | MEROXTI TECHNOLOGY';
$pageDescription = 'Custom software and business systems that help teams work more efficiently — built for scale, security, and long-term reliability.';
$canonicalUrl = '';
$activePage = 'services';

// ✅ FIXED: Dynamic site base path (auto-detect folder)
$siteBase = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/\\');
if ($siteBase === '' || $siteBase === '.' || $siteBase === '/') {
    $siteBase = '';
}

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/navbar.php';
?>

<main id="main-content">

    <!-- HERO SECTION -->
    <section class="ai-hero-section section-shell section-pad">
        <div class="ai-hero-copy reveal">
            <div class="eyebrow">
                <span class="status-dot"></span>
                CUSTOM SOFTWARE ENGINEERING
            </div>
            <h1>
                Software that
                <span class="gradient-text">simplifies complex work.</span>
            </h1>
            <p class="hero-lead">
                We build custom software and business systems that automate workflows, 
                reduce operational overhead, and give your team the tools they actually need.
            </p>
            <div class="hero-actions">
                <a class="btn btn-primary-custom" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                    Discuss your project <span aria-hidden="true">↗</span>
                </a>
                <a class="text-link" href="#software-capabilities">
                    Explore capabilities <span aria-hidden="true">↓</span>
                </a>
            </div>
        </div>

        <div class="ai-hero-visual reveal" aria-hidden="true">
            <div class="visual-glow"></div>

            <div class="ai-core">
                <div class="ai-core-inner">▣</div>
            </div>

            <div class="vip-floating-metric">
                <span class="metric-num">99.9%</span>
                <span class="metric-txt">System Reliability</span>
            </div>

            <div class="vip-floating-metric metric-two">
                <span class="metric-num">3x</span>
                <span class="metric-txt">Workflow Efficiency</span>
            </div>
        </div>
    </section>

    <!-- SOFTWARE CAPABILITIES GRID -->
    <section class="section-shell section-pad" id="software-capabilities">
        <div class="section-heading reveal">
            <div>
                <div class="eyebrow">SOFTWARE CAPABILITIES</div>
                <h2>
                    Built for real business,
                    <span class="gradient-text">engineered to last.</span>
                </h2>
            </div>
            <p>
                From internal tools to customer-facing platforms — we deliver software that grows with your business.
            </p>
        </div>

        <div class="vip-service-grid">
            <article class="vip-service-card reveal">
                <div class="card-top-row">
                    <span class="card-index">01</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>Custom Business Software</h3>
                <p>Tailor-made systems that match your exact workflows — no bloated features, no compromises.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">PHP · Python · Node</span>
                    <a class="card-link" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 100ms;">
                <div class="card-top-row">
                    <span class="card-index">02</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>SaaS Platform Development</h3>
                <p>Multi-tenant cloud applications with subscription billing, user management, and analytics built in.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">Laravel · React</span>
                    <a class="card-link" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 200ms;">
                <div class="card-top-row">
                    <span class="card-index">03</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>Enterprise Resource Systems</h3>
                <p>ERP and CRM systems that unify sales, operations, inventory, and reporting in one place.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">ERP · CRM</span>
                    <a class="card-link" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 300ms;">
                <div class="card-top-row">
                    <span class="card-index">04</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>API Development &amp; Integration</h3>
                <p>REST and GraphQL APIs that connect your tools, automate data flow, and enable third-party access.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">REST · GraphQL</span>
                    <a class="card-link" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 400ms;">
                <div class="card-top-row">
                    <span class="card-index">05</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>Database Architecture</h3>
                <p>Well-designed MySQL, PostgreSQL, and NoSQL schemas built for performance and data integrity.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">MySQL · PostgreSQL</span>
                    <a class="card-link" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 500ms;">
                <div class="card-top-row">
                    <span class="card-index">06</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>Maintenance &amp; Support</h3>
                <p>Ongoing updates, security patches, performance tuning, and feature development for existing systems.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">DevOps · Support</span>
                    <a class="card-link" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>
        </div>
    </section>

    <!-- PROCESS SECTION -->
    <section class="section-shell section-pad">
        <div class="section-heading reveal">
            <div>
                <div class="eyebrow">HOW WE BUILD SOFTWARE</div>
                <h2>
                    From requirements to
                    <span class="gradient-text">reliable delivery.</span>
                </h2>
            </div>
            <p>
                A structured engineering approach that keeps your software stable, secure, and easy to evolve.
            </p>
        </div>

        <div class="process-grid">
            <article class="process-step reveal">
                <span>01</span>
                <div class="process-line"></div>
                <h3>Requirements</h3>
                <p>Map business needs, user roles, and technical constraints clearly.</p>
            </article>

            <article class="process-step reveal">
                <span>02</span>
                <div class="process-line"></div>
                <h3>Architecture</h3>
                <p>Design system structure, database schema, and integration points.</p>
            </article>

            <article class="process-step reveal">
                <span>03</span>
                <div class="process-line"></div>
                <h3>Build &amp; Review</h3>
                <p>Develop in modules with regular demos and stakeholder feedback.</p>
            </article>

            <article class="process-step reveal">
                <span>04</span>
                <div class="process-line"></div>
                <h3>Deploy &amp; Support</h3>
                <p>Launch with monitoring, documentation, and long-term maintenance.</p>
            </article>
        </div>
    </section>

    <!-- CALL TO ACTION -->
    <section class="section-shell section-pad project-preview">
        <div class="project-panel reveal">
            <div class="project-panel-copy">
                <div class="eyebrow">LET'S BUILD YOUR SYSTEM</div>
                <h2>
                    Need custom software
                    <span class="gradient-text">that fits your business?</span>
                </h2>
                <p>
                    Tell us about your workflow and we'll design a software solution built around it.
                </p>
                <a class="btn btn-primary-custom" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                    Discuss your project <span>↗</span>
                </a>
            </div>

            <div class="project-orb" aria-hidden="true">
                <div class="orb-inner">SYS</div>
                <span class="orb-label label-one">CUSTOM</span>
                <span class="orb-label label-two">SCALABLE</span>
                <span class="orb-label label-three">SECURE</span>
            </div>
        </div>
    </section>

</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const animatedItems = document.querySelectorAll('.reveal');

    if (!('IntersectionObserver' in window)) {
        animatedItems.forEach(function (item) {
            item.classList.add('active');
        });
        return;
    }

    const observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1
    });

    animatedItems.forEach(function (item) {
        observer.observe(item);
    });
});
</script>