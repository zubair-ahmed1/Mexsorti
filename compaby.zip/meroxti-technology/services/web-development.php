<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle = 'Web Development | MEROXTI TECHNOLOGY';
$pageDescription = 'Responsive, accessible, performance-minded websites built around your business goals — engineered for speed, SEO, and long-term growth.';
$canonicalUrl = '';
$activePage = 'services';

// ✅ FIXED: Dynamic site base path (auto-detect folder)
$siteBase = rtrim(dirname(dirname($_SERVER['SCRIPT_NAME'])), '/\\');
if ($siteBase === '' || $siteBase === '.' || $siteBase === '/') {
    $siteBase = '';
}

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/navbar.php';
?>

<main id="main-content">

    <!-- HERO SECTION -->
    <section class="ai-hero-section section-shell section-pad">
        <div class="ai-hero-copy reveal">
            <div class="eyebrow">
                <span class="status-dot"></span>
                WEB ENGINEERING
            </div>
            <h1>
                Websites that
                <span class="gradient-text">work as hard as you do.</span>
            </h1>
            <p class="hero-lead">
                We build responsive, accessible, high-performance websites that load fast, 
                rank well, and turn visitors into customers — on every device.
            </p>
            <div class="hero-actions">
                <a class="btn btn-primary-custom" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                    Discuss your project <span aria-hidden="true">↗</span>
                </a>
                <a class="text-link" href="#web-capabilities">
                    Explore capabilities <span aria-hidden="true">↓</span>
                </a>
            </div>
        </div>

        <div class="ai-hero-visual reveal" aria-hidden="true">
            <div class="visual-glow"></div>

            <div class="ai-core">
                <div class="ai-core-inner">⌘</div>
            </div>

            <div class="vip-floating-metric">
                <span class="metric-num">95+</span>
                <span class="metric-txt">PageSpeed Score</span>
            </div>

            <div class="vip-floating-metric metric-two">
                <span class="metric-num">100%</span>
                <span class="metric-txt">Responsive Design</span>
            </div>
        </div>
    </section>

    <!-- WEB CAPABILITIES GRID -->
    <section class="section-shell section-pad" id="web-capabilities">
        <div class="section-heading reveal">
            <div>
                <div class="eyebrow">WEB CAPABILITIES</div>
                <h2>
                    Fast, accessible, and
                    <span class="gradient-text">built to convert.</span>
                </h2>
            </div>
            <p>
                From marketing sites to complex web apps — we deliver websites that perform on every metric that matters.
            </p>
        </div>

        <div class="vip-service-grid">
            <article class="vip-service-card reveal">
                <div class="card-top-row">
                    <span class="card-index">01</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>Business &amp; Corporate Websites</h3>
                <p>Professional websites that establish credibility, communicate value, and convert visitors into leads.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">PHP · WordPress</span>
                    <a class="card-link" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 100ms;">
                <div class="card-top-row">
                    <span class="card-index">02</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>E-Commerce Platforms</h3>
                <p>Secure online stores with product catalogs, payment gateways, and order management built in.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">WooCommerce · Stripe</span>
                    <a class="card-link" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 200ms;">
                <div class="card-top-row">
                    <span class="card-index">03</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>Custom Web Applications</h3>
                <p>Interactive dashboards, portals, and SaaS-style web apps built with modern frameworks.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">Laravel · React</span>
                    <a class="card-link" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 300ms;">
                <div class="card-top-row">
                    <span class="card-index">04</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>Responsive &amp; Mobile-First</h3>
                <p>Pixel-perfect layouts that adapt beautifully to every screen size — phone, tablet, and desktop.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">CSS · Bootstrap</span>
                    <a class="card-link" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 400ms;">
                <div class="card-top-row">
                    <span class="card-index">05</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>SEO &amp; Performance</h3>
                <p>Technical SEO, Core Web Vitals optimization, structured data, and clean semantic markup.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">SEO · Analytics</span>
                    <a class="card-link" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 500ms;">
                <div class="card-top-row">
                    <span class="card-index">06</span>
                    <span class="card-status-badge">Active Module</span>
                </div>
                <h3>Maintenance &amp; Hosting</h3>
                <p>Ongoing updates, security patches, backups, and reliable hosting setup for peace of mind.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">Hosting · DevOps</span>
                    <a class="card-link" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>
        </div>
    </section>

    <!-- PROCESS SECTION -->
    <section class="section-shell section-pad">
        <div class="section-heading reveal">
            <div>
                <div class="eyebrow">HOW WE BUILD WEBSITES</div>
                <h2>
                    From wireframe to
                    <span class="gradient-text">launch-ready site.</span>
                </h2>
            </div>
            <p>
                A clean, transparent process that keeps your website on-brand, on-time, and on-target.
            </p>
        </div>

        <div class="process-grid">
            <article class="process-step reveal">
                <span>01</span>
                <div class="process-line"></div>
                <h3>Discover</h3>
                <p>Understand your goals, audience, competitors, and content needs.</p>
            </article>

            <article class="process-step reveal">
                <span>02</span>
                <div class="process-line"></div>
                <h3>Design</h3>
                <p>Wireframes and visual mockups that align with your brand identity.</p>
            </article>

            <article class="process-step reveal">
                <span>03</span>
                <div class="process-line"></div>
                <h3>Build &amp; Optimize</h3>
                <p>Develop, test responsiveness, and tune for speed and SEO.</p>
            </article>

            <article class="process-step reveal">
                <span>04</span>
                <div class="process-line"></div>
                <h3>Launch &amp; Maintain</h3>
                <p>Deploy, monitor performance, and keep the site secure and updated.</p>
            </article>
        </div>
    </section>

    <!-- CALL TO ACTION -->
    <section class="section-shell section-pad project-preview">
        <div class="project-panel reveal">
            <div class="project-panel-copy">
                <div class="eyebrow">LET'S BUILD YOUR WEBSITE</div>
                <h2>
                    Ready for a website
                    <span class="gradient-text">that actually performs?</span>
                </h2>
                <p>
                    Share your vision and we'll design a website that's fast, functional, and built to grow.
                </p>
                <a class="btn btn-primary-custom" href="<?= htmlspecialchars($siteBase, ENT_QUOTES, 'UTF-8') ?>/contact.php">
                    Discuss your project <span>↗</span>
                </a>
            </div>

            <div class="project-orb" aria-hidden="true">
                <div class="orb-inner">WEB</div>
                <span class="orb-label label-one">FAST</span>
                <span class="orb-label label-two">RESPONSIVE</span>
                <span class="orb-label label-three">SEO-READY</span>
            </div>
        </div>
    </section>

</main>

<?php require __DIR__ . '/../includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const animatedItems = document.querySelectorAll('.reveal');

    if (!('IntersectionObserver' in window)) {
        animatedItems.forEach(function (item) {
            item.classList.add('active');
        });
        return;
    }

    const observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                observer.unobserve(entry.target);
            }
        });
    }, {
        threshold: 0.1
    });

    animatedItems.forEach(function (item) {
        observer.observe(item);
    });
});
</script>