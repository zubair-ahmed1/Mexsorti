<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle = 'UI/UX Design | MEROXTI TECHNOLOGY';
$pageDescription = 'User-centered digital experiences, wireframes, and high-end enterprise UI/UX design that convert visitors into loyal customers.';
$canonicalUrl = '';
$activePage = 'services';

// Absolute base path resolution for root links
$scriptDir = str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME']));
$siteBase = rtrim(dirname($scriptDir), '/');
if ($siteBase === '.' || $siteBase === '/' || $siteBase === '\\') {
    $siteBase = '';
}

function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}

require_once __DIR__ . '/../includes/header.php';
require_once __DIR__ . '/../includes/navbar.php';
?>

<main id="main-content">

    <!-- HERO SECTION -->
    <section class="ai-hero-section section-shell section-pad">
        <div class="ai-hero-copy reveal">
            <div class="eyebrow">
                <span class="status-dot"></span>
                EXPERIENCE DESIGN
            </div>
            <h1>
                Interfaces that captivate,
                <span class="gradient-text">experiences that convert.</span>
            </h1>
            <p class="hero-lead">
                We craft intuitive, engaging, and high-performance UI/UX designs 
                tailored around your users' needs and business goals.
            </p>
            <div class="hero-actions">
                <a class="btn btn-primary-custom" href="<?= e($siteBase) ?>/contact.php">
                    Start a design project <span aria-hidden="true">↗</span>
                </a>
                <a class="text-link" href="#ux-capabilities">
                    Explore design services <span aria-hidden="true">↓</span>
                </a>
            </div>
        </div>

        <div class="ai-hero-visual reveal" aria-hidden="true">
            <div class="visual-glow"></div>

            <div class="ai-core">
                <div class="ai-core-inner">UX</div>
            </div>

            <div class="vip-floating-metric">
                <span class="metric-num">3x</span>
                <span class="metric-txt">Higher User Engagement</span>
            </div>

            <div class="vip-floating-metric metric-two">
                <span class="metric-num">100%</span>
                <span class="metric-txt">Custom Design Systems</span>
            </div>
        </div>
    </section>

    <!-- UI/UX CAPABILITIES GRID -->
    <section class="section-shell section-pad" id="ux-capabilities">
        <div class="section-heading reveal">
            <div>
                <div class="eyebrow">DESIGN CAPABILITIES</div>
                <h2>
                    Thoughtful design for
                    <span class="gradient-text">modern digital products.</span>
                </h2>
            </div>
            <p>
                From user research to pixel-perfect design systems, we shape seamless journeys across web and mobile platforms.
            </p>
        </div>

        <div class="vip-service-grid">
            <article class="vip-service-card reveal">
                <div class="card-top-row">
                    <span class="card-index">01</span>
                    <span class="card-status-badge">Core Service</span>
                </div>
                <h3>User Research &amp; Persona</h3>
                <p>Deep-dive discovery sessions, user interviews, and behavioral mapping to understand your target audience.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">Interviews · Analytics</span>
                    <a class="card-link" href="<?= e($siteBase) ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 100ms;">
                <div class="card-top-row">
                    <span class="card-index">02</span>
                    <span class="card-status-badge">Core Service</span>
                </div>
                <h3>Wireframing &amp; Prototyping</h3>
                <p>Low-to-high fidelity wireframes and interactive prototypes to test user flows before writing a single line of code.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">Figma · Wireframes</span>
                    <a class="card-link" href="<?= e($siteBase) ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>

            <article class="vip-service-card reveal" style="--card-delay: 200ms;">
                <div class="card-top-row">
                    <span class="card-index">03</span>
                    <span class="card-status-badge">Core Service</span>
                </div>
                <h3>Design Systems &amp; UI</h3>
                <p>Scalable, consistent design components and stunning aesthetic interfaces tailored to your brand guidelines.</p>
                <div class="card-bottom-row">
                    <span class="tech-stack-tag">Design Systems · UI Kit</span>
                    <a class="card-link" href="<?= e($siteBase) ?>/contact.php">
                        Learn more <span>↗</span>
                    </a>
                </div>
            </article>
        </div>
    </section>

    <!-- CALL TO ACTION -->
    <section class="section-shell section-pad project-preview">
        <div class="project-panel reveal">
            <div class="project-panel-copy">
                <div class="eyebrow">LET'S CREATE SOMETHING AMAZING</div>
                <h2>
                    Ready to elevate your
                    <span class="gradient-text">user experience?</span>
                </h2>
                <p>
                    Share your vision with us, and let's craft a digital product your users will love.
                </p>
                <a class="btn btn-primary-custom" href="<?= e($siteBase) ?>/contact.php">
                    Discuss your project <span>↗</span>
                </a>
            </div>

            <div class="project-orb" aria-hidden="true">
                <div class="orb-inner">UI</div>
                <span class="orb-label label-one">RESEARCH</span>
                <span class="orb-label label-two">WIREFRAMES</span>
                <span class="orb-label label-three">SYSTEMS</span>
            </div>
        </div>
    </section>

</main>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function () {
    const animatedItems = document.querySelectorAll('.reveal');
    animatedItems.forEach(function (item) {
        item.classList.add('active');
    });
});
</script>