<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$pageTitle = 'Enterprise Digital Services | MEROXTI TECHNOLOGY';
$pageDescription = 'Discover high-performance web development, custom SaaS engineering, AI integrations, and mobile architectures built for rapid business scale.';
$canonicalUrl = '';
$activePage = 'services';

$siteBase = '/meroxti-technology-starter/meroxti-technology';

// Safe Database Connection
if (file_exists(__DIR__ . '/config/database.php')) {
    require_once __DIR__ . '/config/database.php';
} elseif (file_exists(__DIR__ . '/config/dataphase.php')) {
    require_once __DIR__ . '/config/dataphase.php';
} elseif (file_exists(__DIR__ . '/includes/db.php')) {
    require_once __DIR__ . '/includes/db.php';
} else {
    $dbHost = '127.0.0.1';
    $dbName = 'meroxti_technology';
    $dbUser = 'root';
    $dbPass = '';
    try {
        $pdo = new PDO("mysql:host={$dbHost};dbname={$dbName};charset=utf8mb4", $dbUser, $dbPass, [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
        ]);
    } catch (Exception $e) {
        $pdo = null;
    }
}

// Fetch Services from Database or load robust enterprise suite fallback
$servicesList = [];
try {
    if (isset($pdo) && $pdo) {
        $stmt = $pdo->query("SELECT * FROM services WHERE status = 'published' ORDER BY id ASC");
        $servicesList = $stmt->fetchAll();
    }
} catch (Exception $e) {
    $servicesList = [];
}

if (empty($servicesList)) {
    $servicesList = [
        [
            'title' => 'Web Ecosystem Engineering',
            'slug' => 'web-development',
            'short_description' => 'Lightning-fast, conversion-optimized frontend platforms built on modern frameworks with high-availability backend sync.'
        ],
        [
            'title' => 'Custom SaaS & Software',
            'slug' => 'software-development',
            'short_description' => 'Scalable multi-tenant cloud applications designed to automate workflows, secure enterprise data, and cut operational overhead.'
        ],
        [
            'title' => 'Autonomous AI Solutions',
            'slug' => 'ai-solutions',
            'short_description' => 'Custom machine learning models, intelligent chatbots, and automated analytics pipelines tailored to boost corporate velocity.'
        ],
        [
            'title' => 'Native & Cross-Platform Mobile',
            'slug' => 'mobile-app-development',
            'short_description' => 'Sleek, fluid, high-performance mobile applications engineered for exceptional user retention on iOS and Android.'
        ],
        [
            'title' => 'Cloud Infrastructure & DevOps',
            'slug' => 'cloud-devops',
            'short_description' => 'Secure AWS/Azure server setups, automated CI/CD deployment pipelines, and bulletproof database optimization.'
        ],
        [
            'title' => 'UI/UX Brand Architecture',
            'slug' => 'ui-ux-design',
            'short_description' => 'Immersive digital product design, interactive wireframes, and design systems that establish deep market authority.'
        ]
    ];
}

function e($value) {
    return htmlspecialchars((string) $value, ENT_QUOTES, 'UTF-8');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= e($pageTitle) ?></title>
    <meta name="description" content="<?= e($pageDescription) ?>">

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?= e($siteBase) ?>/assets/css/style.css">
</head>
<body>
<a class="skip-link" href="#main-content">Skip to content</a>

<?php 
if (file_exists(__DIR__ . '/includes/navbar.php')) {
    require __DIR__ . '/includes/navbar.php';
}
?>

<main id="main-content">
    <!-- HERO SECTION -->
    <section class="services-hero-section section-shell section-pad">
        <div class="services-hero-copy reveal">
            <div class="eyebrow">
                <span class="status-dot"></span>
                ENTERPRISE CAPABILITIES
            </div>
            <h1>
                Architecting digital futures with
                <span class="gradient-text">precision engineering.</span>
            </h1>
            <p class="hero-lead">
                We combine visionary UI/UX design with battle-tested database architectures 
                to build digital products that dominate markets and scale effortlessly.
            </p>
            <div class="hero-actions">
                <a class="btn btn-primary-custom" href="<?= e($siteBase) ?>/contact.php">
                    Start a project <span aria-hidden="true">↗</span>
                </a>
                <a class="text-link" href="#services-matrix">
                    Explore matrix <span aria-hidden="true">↓</span>
                </a>
            </div>
        </div>

        <div class="services-hero-visual reveal" aria-hidden="true">
            <div class="visual-glow"></div>
            <div class="vip-floating-metric">
                <span class="metric-num">99.9%</span>
                <span class="metric-txt">Uptime SLA Architecture</span>
            </div>
            <div class="vip-floating-metric metric-two">
                <span class="metric-num">4x</span>
                <span class="metric-txt">Average Speed Boost</span>
            </div>
        </div>
    </section>

    <!-- SERVICES MATRIX GRID -->
    <section class="section-shell section-pad" id="services-matrix">
        <div class="section-heading reveal">
            <div>
                <div class="eyebrow">CORE SERVICE MATRIX</div>
                <h2>
                    Engineered for scale,
                    <span class="gradient-text">optimized for impact.</span>
                </h2>
            </div>
            <p>
                Backed by active MySQL schema indexing and robust service pipelines designed for high enterprise workloads.
            </p>
        </div>

        <div class="vip-service-grid">
            <?php foreach ($servicesList as $index => $service): ?>
                <article class="vip-service-card reveal" style="--card-delay: <?= (int)$index * 80 ?>ms">
                    <div class="card-top-row">
                        <span class="card-index"><?= str_pad((string)($index + 1), 2, '0', STR_PAD_LEFT) ?></span>
                        <span class="card-status-badge">Active Module</span>
                    </div>
                    <h3><?= e($service['title']) ?></h3>
                    <p><?= e($service['short_description'] ?? 'High-performance digital engineering solution built to optimize workflows and secure enterprise assets.') ?></p>
                    
                    <div class="card-bottom-row">
                        <span class="tech-stack-tag">Database Synchronized</span>
                        <a class="card-link" href="<?= e($siteBase) ?>/services/<?= e($service['slug'] ?? 'web-development') ?>.php">
                            Deploy solution <span>↗</span>
                        </a>
                    </div>
                </article>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- CALL TO ACTION -->
    <section class="section-shell section-pad project-preview">
        <div class="project-panel reveal">
            <div class="project-panel-copy">
                <div class="eyebrow">READY TO DEPLOY?</div>
                <h2>
                    Transform your digital vision into
                    <span class="gradient-text">an enterprise reality.</span>
                </h2>
                <p>
                    Connect with our technical architects today and get a customized development roadmap.
                </p>
                <a class="btn btn-primary-custom" href="<?= e($siteBase) ?>/contact.php">
                    Initialize consultation <span>↗</span>
                </a>
            </div>

            <div class="project-orb" aria-hidden="true">
                <div class="orb-inner">MX</div>
                <span class="orb-label label-one">SECURITY</span>
                <span class="orb-label label-two">SCALABILITY</span>
                <span class="orb-label label-three">PERFORMANCE</span>
            </div>
        </div>
    </section>
</main>

<?php 
if (file_exists(__DIR__ . '/includes/footer.php')) {
    require __DIR__ . '/includes/footer.php';
}
?>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const animatedItems = document.querySelectorAll('.reveal');
    if (!('IntersectionObserver' in window)) {
        animatedItems.forEach(item => item.classList.add('active'));
        return;
    }
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('active');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.1 });
    animatedItems.forEach(item => observer.observe(item));
});
</script>
</body>
</html>